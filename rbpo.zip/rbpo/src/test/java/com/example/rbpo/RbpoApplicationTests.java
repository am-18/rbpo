package com.example.rbpo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RbpoApplicationTests {

	@Test
	void contextLoads() {
	}

}
